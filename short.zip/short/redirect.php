<?php

$conn = new mysqli("localhost", "bbd_short", "dBLZcyBBYyiaiK2s", "bbd_short");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (isset($_GET['code'])) {
    $short_code = $_GET['code'];
    $stmt = $conn->prepare("SELECT long_url FROM urls WHERE short_code = ?");
    $stmt->bind_param("s", $short_code);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $long_url = $row['long_url'];
        
        // No encoding used here
        $new_url = "https://domainnn.com/link?link=" . $long_url;

        header("Location: " . $new_url);
        exit();
    } else {
        echo "Error: Short URL not found!";
    }
} else {
    echo "Error: No short code provided!";
}

$conn->close();