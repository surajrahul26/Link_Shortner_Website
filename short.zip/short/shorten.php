<?php





$conn = new mysqli("localhost", "bbd_short", "dBLZcyBBYyiaiK2s", "bbd_short");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
function generateShortCode($length = 10) {
    return substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, $length);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $longUrl = $_POST['long_url'];
    $stmt = $conn->prepare("SELECT short_code FROM urls WHERE long_url = ?");
    $stmt->bind_param("s", $longUrl);
    $stmt->execute();
    $stmt->bind_result($existingCode);
    if ($stmt->fetch()) {
        echo "Short URL: https://appsinsta.com/short/" . $existingCode;
        
       
       ?>
       
       
       <div>
           <center>
           <b>SACN THIS QR TO OPEN THE SHORT LINK:</b>
           </center>
       </div>
       
       <div>
           <center>
       <?php
        
   
$key = "J6PyjdliU2puqzm940tZFacr1gAswH8v";      //replace with your unique api key
$text = "https://appsinsta.com/short/" . $existingCode;        //replace with what you want to turn into a QR code

//create the main url to call the api using your details. Make sure you urlencode the text part to be safe!

     
     
$url_to_return_qrcode = "https://www.qrcoder.co.uk/api/v4/?key=" . $key . "&text=" . urlencode($text);

echo "<img src=\"" . $url_to_return_qrcode . "\" />";


        $stmt->close();
        $conn->close();
        exit();
    }
    $stmt->close();
    do {
        $shortCode = generateShortCode();
        $stmt = $conn->prepare("SELECT id FROM urls WHERE short_code = ?");
        $stmt->bind_param("s", $shortCode);
        $stmt->execute();
        $stmt->store_result();
    } while ($stmt->num_rows > 0);
    $stmt->close();
    $stmt = $conn->prepare("INSERT INTO urls (long_url, short_code) VALUES (?, ?)");
    $stmt->bind_param("ss", $longUrl, $shortCode);
    $stmt->execute();
    echo "Short URL: https://appsinsta.com/short/" . $shortCode; 

    $stmt->close();
}
$conn->close();

?>
</center>
</div>

