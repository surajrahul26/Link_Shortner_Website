<?php
$conn = new mysqli("localhost", "bbd_short", "dBLZcyBBYyiaiK2s", "bbd_short");
if ($conn->connect_error) {
    die("DB error");
}

function generateShortCode($length = 10) {
    return substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, $length);
}

// Support GET ?link=originalURL
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['link'])) {
    $longUrl = $_GET['link'];

    if (!filter_var($longUrl, FILTER_VALIDATE_URL)) {
        http_response_code(400);
        echo "Invalid URL";
        exit();
    }

    $stmt = $conn->prepare("SELECT short_code FROM urls WHERE long_url = ?");
    $stmt->bind_param("s", $longUrl);
    $stmt->execute();
    $stmt->bind_result($existingCode);
    if ($stmt->fetch()) {
        header("Location: https://appsinsta.com/short/" . $existingCode);
        exit();
    }
    $stmt->close();

    do {
        $shortCode = generateShortCode();
        $stmt = $conn->prepare("SELECT id FROM urls WHERE short_code = ?");
        $stmt->bind_param("s", $shortCode);
        $stmt->execute();
        $stmt->store_result();
    } while ($stmt->num_rows > 0);
    $stmt->close();

    $stmt = $conn->prepare("INSERT INTO urls (long_url, short_code) VALUES (?, ?)");
    $stmt->bind_param("ss", $longUrl, $shortCode);
    $stmt->execute();

    header("Location: https://appsinsta.com/short/" . $shortCode);
    exit();
}
?>