<?php
$key = "J6PyjdliU2puqzm940tZFacr1gAswH8v";      //replace with your unique api key
$text = "https://shortlinks.com";        //replace with what you want to turn into a QR code

//create the main url to call the api using your details. Make sure you urlencode the text part to be safe!
$url_to_return_qrcode = "https://www.qrcoder.co.uk/api/v4/?key=" . $key . "&text=" . urlencode($text);

echo "<img src=\"" . $url_to_return_qrcode . "\" />";

?>